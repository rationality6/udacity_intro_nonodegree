
CREATE TABLE posts (content TEXT, TIME TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                                                         id SERIAL);
