Project Title:

Udacity database course's final project a swiss system tournament.

Installation/ Quickstart:

Requirement.

Python2.
PostgreSQL.

How to run.

first, import tournament.sql

~ : psql vagrant
vagrant : \i tournament.sql
vagrant : \q

after that you can test the APIs for tournament

like

: python tournament_test.py


Thank you. :)
